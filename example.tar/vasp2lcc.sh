#!/bin/sh
#usage to generate input)    vasp2lcc.sh . POXTRD_b
#usage to execute code) mpiexec -n ${nprocs} ${programdir}/CFSDM.x inp ${prefix}.xyz > ${prefix}.log
tag=$2
CONTCAR=$1/POSCAR
OUTCAR=$1/mbd.rsscs.fi/OUTCAR
POTCAR=$1/POTCAR
head -7 $CONTCAR > "$tag".xyz0
echo  "Selective dynamics" >> "$tag".xyz0
grep -i "direct\|cartesian" $CONTCAR >> "$tag".xyz0
grep -A1 "Selective dynamics" $CONTCAR >> "$tag".xyz0
sum=0
for i in `sed '7q;d' $CONTCAR`
do
  ((sum+=i))
done

grep -i -A $sum 'Direct' $CONTCAR | tail -n +2 | sed 's/ T//g' > xyz  #if periodic
#grep -i -A $sum 'Cartesian' $CONTCAR | tail -n +2 | sed 's/ T//g' > xyz   #if non-periodic

grep -A $((sum+3)) 'Parameters of vdW forcefield' $OUTCAR | tail -n $sum | awk '{print "  "$NF}' > relvol
paste xyz relvol > inff

elem_ref=(H Li C O S Ti V Sn Pt N P Co)
elem_ind=(1 3 6 8 16 22 23 50 78 7 15 27)
list=()
if [ `grep IVDW $OUTCAR | awk '{print $NF}'` -eq 263 ]
then
  grep -A $((sum+2)) "Hirshfeld-I charges" $OUTCAR | tail -n $sum | awk '{print $3}' > ionchg
  elem=(`grep VRHFIN $OUTCAR | awk -F[=::] '{print $2}'`)
  n=0
  for l in ${elem[@]}
  do
    for n in `seq 0 ${#elem_ref[@]}`
    do
      [ "$l" == "${elem_ref[$n]}" ] && list+=(${elem_ind[$n]})
    done
  done
  k=0
  for i in `grep "ions per type" $OUTCAR | sed "s/ions per type =//g"`
  do
    for j in `seq 1 $i`
    do
      echo ${list[$k]} >> zval
    done
    k=$((k+1))
  done
  
  paste zval ionchg > ionchg-zval

  while read line
  do
    echo $line | awk '{print "  "$1-$2}'
  done < ionchg-zval > chg

  #echo "T T T" > relvol
  paste inff chg > inf
else
  mv inff inf
fi

cat inf >> "$tag".xyz0
rm -f inf xyz relvol inff chg ionchg ionchg-zval zval
sed 's/\t//g' "$tag".xyz0 > "$tag".xyz
rm -f "$tag".xyz0
